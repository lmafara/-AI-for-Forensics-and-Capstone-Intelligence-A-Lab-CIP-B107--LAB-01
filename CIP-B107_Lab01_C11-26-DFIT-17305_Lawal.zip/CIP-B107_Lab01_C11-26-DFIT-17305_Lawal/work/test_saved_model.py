import pandas as pd
import joblib

model = joblib.load("outputs/ip_classifier.pkl")

df = pd.read_csv("outputs/phase_c_prepared.csv")

sample = (
    df["text"].fillna("").astype(str)
    + " "
    + df["ip"].fillna("").astype(str)
).head(5)

predictions = model.predict(sample)

print("Saved model loaded successfully.")
print("\nSample predictions:")

for i, prediction in enumerate(predictions, start=1):
    label = "Positive" if prediction == 1 else "Negative"
    print(f"Record {i}: {label}")
