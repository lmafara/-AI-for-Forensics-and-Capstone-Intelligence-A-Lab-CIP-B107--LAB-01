import json
import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

def load_data(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

def label_value(record):
    value = record["completion"].strip().lower()
    return 1 if value == "positive" else 0

train = load_data("originals/dataset_train.jsonl")
test = load_data("originals/dataset_test.jsonl")

test_prompts = {r["prompt"] for r in test}

filtered_train = [
    r for r in train if r["prompt"] not in test_prompts
]

X_train = [r["prompt"] for r in filtered_train]
y_train = [label_value(r) for r in filtered_train]

X_test = [r["prompt"] for r in test]
y_test = [label_value(r) for r in test]

model = Pipeline([
    ("tfidf", TfidfVectorizer(
        analyzer="char",
        ngram_range=(2, 5)
    )),
    ("classifier", LogisticRegression(
        max_iter=1000,
        class_weight="balanced",
        random_state=42
    ))
])

model.fit(X_train, y_train)
predictions = model.predict(X_test)

metrics = {
    "accuracy": accuracy_score(y_test, predictions),
    "precision": precision_score(y_test, predictions, zero_division=0),
    "recall": recall_score(y_test, predictions, zero_division=0),
    "f1": f1_score(y_test, predictions, zero_division=0)
}

cm = confusion_matrix(y_test, predictions, labels=[0, 1])

result = pd.DataFrame({
    "prompt": X_test,
    "actual_label": y_test,
    "predicted_label": predictions
})

result.to_csv(
    "outputs/leakage_reduced_predictions.csv",
    index=False
)

with open("outputs/leakage_sensitivity.txt", "w") as f:
    f.write("LEAKAGE SENSITIVITY ANALYSIS\n")
    f.write(f"Original training records: {len(train)}\n")
    f.write(f"Training records after overlap removal: {len(filtered_train)}\n")
    f.write(f"Removed training records: {len(train) - len(filtered_train)}\n")
    f.write(f"Test records: {len(test)}\n\n")

    for name, value in metrics.items():
        f.write(f"{name}: {value:.4f}\n")

    f.write("\nConfusion matrix [[TN, FP], [FN, TP]]:\n")
    f.write(str(cm) + "\n")

print("Original training records:", len(train))
print("Training records after overlap removal:", len(filtered_train))
print("Removed training records:", len(train) - len(filtered_train))
print("Test records:", len(test))
print("\nLeakage-reduced evaluation:")
for name, value in metrics.items():
    print(f"{name}: {value:.4f}")

print("\nConfusion matrix:")
print(cm)

print("\nSaved:")
print("outputs/leakage_reduced_predictions.csv")
print("outputs/leakage_sensitivity.txt")
