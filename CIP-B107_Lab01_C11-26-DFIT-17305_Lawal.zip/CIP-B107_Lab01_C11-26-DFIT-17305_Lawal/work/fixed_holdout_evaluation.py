import json
import re
import ipaddress
import joblib
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

def load_jsonl(path):
    records = []
    with open(path, "r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if line.strip():
                record = json.loads(line)
                if "prompt" not in record or "completion" not in record:
                    raise ValueError(
                        f"Missing prompt/completion in {path}, line {line_number}"
                    )
                records.append(record)
    return records

def convert_label(completion):
    value = completion.strip().lower()
    if value == "positive":
        return 1
    if value == "negative":
        return 0
    raise ValueError(f"Unexpected completion label: {completion!r}")

train_records = load_jsonl("originals/dataset_train.jsonl")
test_records = load_jsonl("originals/dataset_test.jsonl")

X_train = [r["prompt"] for r in train_records]
y_train = [convert_label(r["completion"]) for r in train_records]

X_test = [r["prompt"] for r in test_records]
y_test = [convert_label(r["completion"]) for r in test_records]

print("Training records:", len(X_train))
print("Testing records:", len(X_test))
print("Training label counts:", pd.Series(y_train).value_counts().to_dict())
print("Testing label counts:", pd.Series(y_test).value_counts().to_dict())

# Check for exact prompt overlap between the supplied splits
train_prompts = set(X_train)
overlap = sum(prompt in train_prompts for prompt in X_test)
print("Exact prompt overlaps across splits:", overlap)

# Train only on the supplied training records
model = Pipeline([
    ("tfidf", TfidfVectorizer(
        analyzer="char",
        ngram_range=(2, 5)
    )),
    ("classifier", LogisticRegression(
        max_iter=1000,
        class_weight="balanced",
        random_state=42
    ))
])

print("\nTraining fixed-holdout model...")
model.fit(X_train, y_train)

# Predict the untouched supplied test set
predictions = model.predict(X_test)
probabilities = model.predict_proba(X_test)[:, 1]

# Rule-based baseline: positive if prompt contains a strictly valid IPv4
ip_pattern = re.compile(
    r"(?<![0-9A-Za-z.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![0-9A-Za-z.])"
)

baseline_predictions = []
for prompt in X_test:
    found_valid_ip = False
    for candidate in ip_pattern.findall(prompt):
        try:
            ipaddress.IPv4Address(candidate)
            found_valid_ip = True
            break
        except ipaddress.AddressValueError:
            pass
    baseline_predictions.append(1 if found_valid_ip else 0)

# Save every test prediction
results = pd.DataFrame({
    "prompt": X_test,
    "actual_label": y_test,
    "actual_class": ["Positive" if y == 1 else "Negative" for y in y_test],
    "predicted_label": predictions,
    "predicted_class": [
        "Positive" if y == 1 else "Negative" for y in predictions
    ],
    "positive_probability": probabilities,
    "baseline_prediction": baseline_predictions,
    "baseline_class": [
        "Positive" if y == 1 else "Negative"
        for y in baseline_predictions
    ]
})

results.to_csv("outputs/predictions.csv", index=False)

def calculate_metrics(actual, predicted):
    return {
        "accuracy": accuracy_score(actual, predicted),
        "precision": precision_score(actual, predicted, zero_division=0),
        "recall": recall_score(actual, predicted, zero_division=0),
        "f1": f1_score(actual, predicted, zero_division=0),
        "confusion_matrix": confusion_matrix(
            actual, predicted, labels=[0, 1]
        )
    }

model_metrics = calculate_metrics(y_test, predictions)
baseline_metrics = calculate_metrics(y_test, baseline_predictions)

# Save model and metrics
joblib.dump(model, "outputs/fixed_holdout_classifier.pkl")

with open("outputs/fixed_holdout_metrics.txt", "w") as file:
    file.write("ICDFA CIP-B107 FIXED-HOLDOUT EVALUATION\n")
    file.write("Training records: 183 expected\n")
    file.write("Testing records: 46 expected\n")
    file.write(f"Exact prompt overlap: {overlap}\n\n")

    for name, metrics in [
        ("TF-IDF + Logistic Regression", model_metrics),
        ("Rule-based IPv4 baseline", baseline_metrics)
    ]:
        file.write(name + "\n")
        for metric in ["accuracy", "precision", "recall", "f1"]:
            file.write(f"{metric}: {metrics[metric]:.4f}\n")
        file.write("Confusion matrix [ [TN, FP], [FN, TP] ]:\n")
        file.write(str(metrics["confusion_matrix"]) + "\n\n")

    file.write("MODEL CLASSIFICATION REPORT\n")
    file.write(classification_report(
        y_test, predictions,
        labels=[0, 1],
        target_names=["Negative", "Positive"],
        zero_division=0
    ))

# Save a confusion matrix chart for the fixed holdout
cm = model_metrics["confusion_matrix"]

plt.figure(figsize=(6, 5))
plt.imshow(cm)
plt.title("Fixed JSONL Holdout - Model Confusion Matrix")
plt.xlabel("Predicted label")
plt.ylabel("Actual label")
plt.xticks([0, 1], ["Negative (0)", "Positive (1)"])
plt.yticks([0, 1], ["Negative (0)", "Positive (1)"])

for row in range(2):
    for col in range(2):
        plt.text(col, row, str(cm[row, col]), ha="center", va="center")

plt.tight_layout()
plt.savefig(
    "outputs/charts/fixed_holdout_confusion_matrix.png",
    dpi=300
)
plt.close()

print("\nFIXED-HOLDOUT MODEL RESULTS")
print(classification_report(
    y_test, predictions,
    labels=[0, 1],
    target_names=["Negative", "Positive"],
    zero_division=0
))
print("Confusion matrix:")
print(cm)

print("\nRULE-BASED BASELINE RESULTS")
print("Accuracy:", round(baseline_metrics["accuracy"], 4))
print("Precision:", round(baseline_metrics["precision"], 4))
print("Recall:", round(baseline_metrics["recall"], 4))
print("F1:", round(baseline_metrics["f1"], 4))
print("Confusion matrix:")
print(baseline_metrics["confusion_matrix"])

print("\nSaved:")
print("- outputs/predictions.csv")
print("- outputs/fixed_holdout_metrics.txt")
print("- outputs/fixed_holdout_classifier.pkl")
print("- outputs/charts/fixed_holdout_confusion_matrix.png")
