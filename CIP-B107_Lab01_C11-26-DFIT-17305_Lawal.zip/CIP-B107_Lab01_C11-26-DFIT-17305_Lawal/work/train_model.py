import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load the prepared dataset
df = pd.read_csv("outputs/phase_c_prepared.csv")

# Prepare text and labels
X = (
    df["text"].fillna("").astype(str)
    + " "
    + df["ip"].fillna("").astype(str)
)
y = df["label"].astype(int)

print("Dataset loaded:", len(df), "records")
print("Label distribution:")
print(y.value_counts().sort_index())

# Split the data while preserving the label proportions
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.25,
    random_state=42,
    stratify=y
)

# Build and train the model
model = Pipeline([
    ("tfidf", TfidfVectorizer(analyzer="char", ngram_range=(2, 5))),
    ("classifier", LogisticRegression(
        max_iter=1000,
        class_weight="balanced"
    ))
])

print("\nTraining model...")
model.fit(X_train, y_train)

# Evaluate the model
predictions = model.predict(X_test)

print("\nAccuracy:", accuracy_score(y_test, predictions))
print("\nClassification report:")
print(classification_report(y_test, predictions, zero_division=0))
print("\nConfusion matrix:")
print(confusion_matrix(y_test, predictions))

# Save the trained model
joblib.dump(model, "outputs/ip_classifier.pkl")
print("\nModel saved to outputs/ip_classifier.pkl")
