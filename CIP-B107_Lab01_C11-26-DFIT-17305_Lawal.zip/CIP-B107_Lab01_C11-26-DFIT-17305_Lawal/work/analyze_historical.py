import os
import pandas as pd
import matplotlib.pyplot as plt

os.makedirs("outputs/charts", exist_ok=True)

df = pd.read_csv("originals/result.csv")

# 1. Historical training loss
plt.figure(figsize=(10, 5))
plt.plot(df["step"], df["training_loss"])
plt.title("Historical Fine-Tuning Training Loss")
plt.xlabel("Training Step")
plt.ylabel("Training Loss")
plt.grid(True)
plt.tight_layout()
plt.savefig("outputs/charts/historical_training_loss.png", dpi=300)
plt.close()

# 2. Available classification accuracy
metric = "classification/accuracy"
available = df.dropna(subset=[metric])

plt.figure(figsize=(10, 5))
if not available.empty:
    plt.plot(available["step"], available[metric], marker="o")
plt.title("Historical Classification Accuracy")
plt.xlabel("Training Step")
plt.ylabel("Classification Accuracy")
plt.ylim(0, 1.05)
plt.grid(True)
plt.tight_layout()
plt.savefig(
    "outputs/charts/historical_classification_accuracy.png",
    dpi=300
)
plt.close()

# 3. Available validation loss
validation = df.dropna(subset=["validation_loss"])

plt.figure(figsize=(10, 5))
if not validation.empty:
    plt.plot(
        validation["step"],
        validation["validation_loss"],
        marker="o"
    )
plt.title("Historical Validation Loss")
plt.xlabel("Training Step")
plt.ylabel("Validation Loss")
plt.grid(True)
plt.tight_layout()
plt.savefig("outputs/charts/historical_validation_loss.png", dpi=300)
plt.close()

# Extract final non-null historical classification metrics
metrics = {
    "Accuracy": "classification/accuracy",
    "Precision": "classification/precision",
    "Recall": "classification/recall",
    "F1-score": "classification/f1.0",
    "AUROC": "classification/auroc",
    "AUPRC": "classification/auprc"
}

with open("outputs/historical_metrics_summary.txt", "w") as f:
    f.write("ICDFA CIP-B107 - HISTORICAL FINE-TUNING ANALYSIS\n\n")
    f.write(f"Total result records: {len(df)}\n")
    f.write(f"First recorded step: {df['step'].min()}\n")
    f.write(f"Last recorded step: {df['step'].max()}\n")
    f.write(
        "Rows with missing classification accuracy: "
        f"{df['classification/accuracy'].isna().sum()}\n\n"
    )

    f.write("FINAL NON-NULL CLASSIFICATION METRICS\n")
    for label, column in metrics.items():
        values = df.dropna(subset=[column])
        if not values.empty:
            last = values.iloc[-1]
            f.write(
                f"{label}: {last[column]:.6f} "
                f"(step {int(last['step'])})\n"
            )
        else:
            f.write(f"{label}: Not available\n")

    f.write("\nINTERPRETATION\n")
    f.write(
        "These are supplied historical experiment metrics. "
        "They are not results from the student's newly trained "
        "offline classifier and do not independently establish "
        "generalization to unseen forensic evidence.\n"
    )

print("Historical analysis completed.")
print("Charts and summary saved.")

print("\nFinal non-null historical metrics:")
for label, column in metrics.items():
    values = df.dropna(subset=[column])
    if not values.empty:
        last = values.iloc[-1]
        print(f"{label}: {last[column]:.6f} at step {int(last['step'])}")
    else:
        print(f"{label}: Not available")
