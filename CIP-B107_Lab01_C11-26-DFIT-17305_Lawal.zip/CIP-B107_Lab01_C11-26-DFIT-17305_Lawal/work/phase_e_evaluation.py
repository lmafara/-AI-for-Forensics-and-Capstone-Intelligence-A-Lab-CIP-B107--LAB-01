import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

source = "outputs/predictions.csv"
df = pd.read_csv(source)

required = [
    "actual_label",
    "predicted_label",
    "baseline_prediction"
]

for column in required:
    if column not in df.columns:
        raise ValueError(f"Missing required column: {column}")

actual = df["actual_label"].astype(int)
predicted = df["predicted_label"].astype(int)
baseline = df["baseline_prediction"].astype(int)

def category(y, p):
    if y == 1 and p == 1:
        return "TP"
    if y == 0 and p == 0:
        return "TN"
    if y == 0 and p == 1:
        return "FP"
    return "FN"

df["model_result"] = [
    category(y, p) for y, p in zip(actual, predicted)
]

df["baseline_result"] = [
    category(y, p) for y, p in zip(actual, baseline)
]

# Majority-class baseline: predict the most common training label.
majority_label = 1
df["majority_prediction"] = majority_label
df["majority_result"] = [
    category(y, p)
    for y, p in zip(actual, df["majority_prediction"])
]

df.to_csv("outputs/phase_e_predictions.csv", index=False)

def calculate_metrics(name, y, p):
    matrix = confusion_matrix(y, p, labels=[0, 1])
    return {
        "Evaluation": name,
        "Accuracy": accuracy_score(y, p),
        "Precision": precision_score(y, p, zero_division=0),
        "Recall": recall_score(y, p, zero_division=0),
        "F1-score": f1_score(y, p, zero_division=0),
        "TN": matrix[0, 0],
        "FP": matrix[0, 1],
        "FN": matrix[1, 0],
        "TP": matrix[1, 1]
    }

results = [
    calculate_metrics("Offline model", actual, predicted),
    calculate_metrics("Rule-based baseline", actual, baseline),
    calculate_metrics(
        "Majority-class baseline",
        actual,
        df["majority_prediction"]
    )
]

metrics = pd.DataFrame(results)
metrics.to_csv("outputs/phase_e_metrics.csv", index=False)

with open("outputs/phase_e_evaluation_summary.txt", "w") as f:
    f.write("ICDFA CIP-B107 - PHASE E EVALUATION\n\n")
    f.write(f"Fixed holdout records: {len(df)}\n")
    f.write(
        f"Actual negative records: {(actual == 0).sum()}\n"
    )
    f.write(
        f"Actual positive records: {(actual == 1).sum()}\n\n"
    )

    f.write("MODEL, BASELINE AND CONFUSION RESULTS\n")
    f.write(metrics.to_string(index=False))
    f.write("\n\nOFFLINE MODEL CLASSIFICATION REPORT\n")
    f.write(
        classification_report(
            actual,
            predicted,
            labels=[0, 1],
            target_names=["Negative", "Positive"],
            zero_division=0
        )
    )

    f.write(
        "\nINTERPRETATION AND LIMITATIONS\n"
        "Positive and Negative refer to the source dataset labels. "
        "They do not establish whether an IP address is malicious.\n"
        "The fixed holdout contains repeated prompts and overlaps "
        "with training prompts. Therefore, performance may be "
        "optimistic and should be interpreted with the leakage "
        "sensitivity analysis.\n"
    )

print("Phase E evaluation completed.")
print("\nEvaluation metrics:")
print(metrics.to_string(index=False))
print("\nModel result counts:")
print(df["model_result"].value_counts().to_string())
print("\nSaved:")
print("outputs/phase_e_predictions.csv")
print("outputs/phase_e_metrics.csv")
print("outputs/phase_e_evaluation_summary.txt")
