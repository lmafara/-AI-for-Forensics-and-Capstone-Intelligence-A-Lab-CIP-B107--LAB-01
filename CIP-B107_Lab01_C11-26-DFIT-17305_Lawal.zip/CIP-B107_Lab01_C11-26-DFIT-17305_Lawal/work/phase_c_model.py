import pandas as pd
import ipaddress
from pathlib import Path

BASE = Path("originals")
OUT = Path("outputs")
OUT.mkdir(exist_ok=True)

df = pd.read_csv(BASE / "dataset_small.csv")

print("\n===== PHASE C: DATASET PREPARATION =====")
print("Original records:", len(df))

clean = df.drop_duplicates(
    subset=["ip", "class", "text"]
).copy()

print("Records after exact deduplication:", len(clean))

clean["label"] = (clean["class"] != "N").astype(int)

print("\n===== CLASS DISTRIBUTION =====")
print(clean["label"].value_counts())

def valid_ipv4(value):
    try:
        ipaddress.IPv4Address(str(value))
        return True
    except ValueError:
        return False

clean["ipv4_valid"] = clean["ip"].apply(valid_ipv4)

print("\n===== IPV4 VALIDATION =====")
print(clean["ipv4_valid"].value_counts())

clean.to_csv(OUT / "phase_c_prepared.csv", index=False)

print("\nSaved: outputs/phase_c_prepared.csv")
print("\nPHASE C PREPARATION COMPLETE")
