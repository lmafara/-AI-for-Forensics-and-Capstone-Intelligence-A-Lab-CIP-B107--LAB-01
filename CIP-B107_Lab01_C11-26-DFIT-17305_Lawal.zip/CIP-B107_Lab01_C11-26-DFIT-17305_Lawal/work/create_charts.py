import os
import pandas as pd
import matplotlib.pyplot as plt

os.makedirs("outputs/charts", exist_ok=True)

# Load project datasets
prepared = pd.read_csv("outputs/phase_c_prepared.csv")
candidates = pd.read_csv("outputs/candidate_review.csv")

# 1. Class distribution
class_counts = prepared["label"].map({
    0: "Negative",
    1: "Positive"
}).value_counts()

plt.figure(figsize=(8, 5))
class_counts.plot(kind="bar")
plt.title("Dataset Class Distribution")
plt.xlabel("Class")
plt.ylabel("Number of Records")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("outputs/charts/class_distribution.png", dpi=300)
plt.close()

# 2. IPv4 validity among extracted candidates
validity_counts = candidates["ipv4_valid"].map({
    True: "Valid IPv4",
    False: "Invalid IPv4"
}).value_counts()

plt.figure(figsize=(8, 5))
validity_counts.plot(kind="bar")
plt.title("IPv4 Candidate Validation")
plt.xlabel("Validation Result")
plt.ylabel("Number of Candidates")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("outputs/charts/ipv4_validity.png", dpi=300)
plt.close()

# 3. Model confusion matrix from the recorded test results
confusion = [
    [2, 2],
    [0, 34]
]

plt.figure(figsize=(6, 5))
plt.imshow(confusion)
plt.title("Model Confusion Matrix")
plt.xlabel("Predicted Label")
plt.ylabel("Actual Label")
plt.xticks([0, 1], ["Negative (0)", "Positive (1)"])
plt.yticks([0, 1], ["Negative (0)", "Positive (1)"])

for row in range(2):
    for col in range(2):
        plt.text(col, row, str(confusion[row][col]),
                 ha="center", va="center")

plt.tight_layout()
plt.savefig("outputs/charts/confusion_matrix.png", dpi=300)
plt.close()

print("All three charts created successfully.")
print("Saved in outputs/charts/")
