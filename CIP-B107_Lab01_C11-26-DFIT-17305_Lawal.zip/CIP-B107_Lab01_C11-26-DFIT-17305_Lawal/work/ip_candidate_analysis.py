import pandas as pd
import re
import ipaddress
from pathlib import Path

BASE = Path("originals")
OUTPUT = Path("outputs")
OUTPUT.mkdir(exist_ok=True)

df = pd.read_csv(BASE / "dataset_small.csv")

pattern = re.compile(
    r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])"
)

results = []

for index, row in df.iterrows():

    context = str(row["text"])
    supplied_ip = str(row["ip"])

    # Extract unique candidates from original text
    candidates = list(dict.fromkeys(
        pattern.findall(context)
    ))

    # Preserve supplied IP if not already extracted
    if pattern.fullmatch(supplied_ip):
        if supplied_ip not in candidates:
            candidates.append(supplied_ip)

    label = "positive" if row["class"] != "N" else "negative"

    for candidate in candidates:

        try:
            ipaddress.IPv4Address(candidate)
            valid = True
            note = "Valid IPv4 syntax"
        except ipaddress.AddressValueError:
            valid = False
            note = "Invalid IPv4 syntax"

        results.append({
            "source_row": index + 1,
            "context": context,
            "candidate": candidate,
            "ipv4_valid": valid,
            "source_label": label,
            "analyst_note": note
        })

review = pd.DataFrame(results)

review.to_csv(
    OUTPUT / "candidate_review.csv",
    index=False
)

print("\n===== CORRECTED IP ANALYSIS =====")
print("Source records:", len(df))
print("Candidates extracted:", len(review))
print("Valid IPv4:", review["ipv4_valid"].sum())
print("Invalid IPv4:", (~review["ipv4_valid"]).sum())

print("\n===== SOURCE LABELS =====")
print(review["source_label"].value_counts())

print("\n===== FIRST 15 CANDIDATES =====")
print(review.head(15).to_string(index=False))

print("\nSaved: outputs/candidate_review.csv")
print("ANALYSIS COMPLETE")
