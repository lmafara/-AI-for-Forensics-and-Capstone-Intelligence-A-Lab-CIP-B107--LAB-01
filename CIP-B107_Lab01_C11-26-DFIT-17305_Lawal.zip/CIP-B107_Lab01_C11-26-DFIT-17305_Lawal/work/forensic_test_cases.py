

import pandas as pd
from pathlib import Path

df = pd.read_csv("outputs/candidate_review.csv")

# Select examples representing different cases
samples = []

# Invalid IPv4 examples
invalid = df[df["ipv4_valid"] == False]
samples.extend(invalid.head(3).to_dict("records"))

# Valid IPv4 examples
valid = df[df["ipv4_valid"] == True]
samples.extend(valid.head(4).to_dict("records"))

# Embedded IP examples
embedded = df[
    df["context"].str.contains("obfs4", case=False, na=False)
]
samples.extend(embedded.head(3).to_dict("records"))

review = pd.DataFrame(samples).drop_duplicates(
    subset=["source_row", "candidate"]
).head(10)

review["case_number"] = range(1, len(review) + 1)

review["forensic_finding"] = review.apply(
    lambda r: (
        "Valid IPv4 syntax"
        if r["ipv4_valid"]
        else "Invalid IPv4 syntax"
    ),
    axis=1
)

review = review[
    [
        "case_number",
        "source_row",
        "context",
        "candidate",
        "ipv4_valid",
        "source_label",
        "forensic_finding"
    ]
]

review.to_csv(
    "outputs/forensic_test_cases.csv",
    index=False
)

print("\n===== FORENSIC TEST CASES =====")
print(review.to_string(index=False))
print("\nTotal cases:", len(review))
print("\nSaved: outputs/forensic_test_cases.csv")
