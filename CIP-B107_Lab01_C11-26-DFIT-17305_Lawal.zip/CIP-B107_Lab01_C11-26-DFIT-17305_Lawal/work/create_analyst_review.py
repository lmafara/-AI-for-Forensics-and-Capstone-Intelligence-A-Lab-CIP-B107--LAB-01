import pandas as pd

source = "outputs/candidate_review.csv"
output = "outputs/eight_record_analyst_review.csv"

df = pd.read_csv(source)

required = [
    "source_row", "context", "candidate",
    "ipv4_valid", "source_label", "analyst_note"
]

for col in required:
    if col not in df.columns:
        raise ValueError(f"Missing column: {col}")

df["source_label"] = df["source_label"].astype(str).str.lower()
df["ipv4_valid"] = (
    df["ipv4_valid"].astype(str).str.lower().map(
        {"true": True, "false": False}
    )
)

selected = []

for label in ["positive", "negative"]:
    group = df[df["source_label"] == label].copy()

    # Prefer distinct candidate/context combinations.
    group = group.drop_duplicates(
        subset=["candidate", "context"]
    )

    # Select up to two valid and two invalid examples.
    valid = group[group["ipv4_valid"] == True].head(2)
    invalid = group[group["ipv4_valid"] == False].head(2)

    chosen = pd.concat([valid, invalid])

    # Fill any shortfall from the remaining records.
    if len(chosen) < 4:
        remaining = group.drop(index=chosen.index, errors="ignore")
        chosen = pd.concat([chosen, remaining.head(4 - len(chosen))])

    if len(chosen) < 4:
        raise ValueError(
            f"Not enough distinct records for source label: {label}"
        )

    selected.append(chosen.head(4))

review = pd.concat(selected, ignore_index=True)

review.insert(
    len(review.columns),
    "analyst_assessment",
    ""
)
review.insert(
    len(review.columns),
    "analyst_rationale",
    ""
)

review.to_csv(output, index=False)

print("Eight-record analyst review created.")
print("\nSource-label counts:")
print(review["source_label"].value_counts().to_string())

print("\nIPv4 validity by source label:")
print(
    pd.crosstab(
        review["source_label"],
        review["ipv4_valid"]
    ).to_string()
)

print("\nSelected records:")
print(
    review[
        ["source_row", "candidate", "ipv4_valid",
         "source_label", "analyst_note"]
    ].to_string(index=False)
)

print(f"\nSaved: {output}")
